<?php
require_once 'partials.php';
require_login();
if($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    $method=$_POST['method']??'';
    $allowed=['bKash','Nagad','Card','Bank Transfer'];
    if(!in_array($method, $allowed, true)) {
        flash('Select a payment method.');
        header('Location: pay-all.php');
        exit;
    }
    $pdo=db();
    $pdo->beginTransaction();
    try {
        $q=$pdo->prepare("SELECT * FROM bills WHERE user_id=? AND status='Unpaid' FOR UPDATE");
        $q->execute([$_SESSION['user_id']]);
        $bills=$q->fetchAll();
        foreach($bills as $b) {
            $txn='NS'.date('YmdHis').random_int(100, 999);
            $amount=$b['amount']+$b['late_fee'];
            $ins=$pdo->prepare("INSERT INTO payments(user_id,bill_id,transaction_id,amount,method,status) VALUES(?,?,?,?,?,'Successful')");
            $ins->execute([$_SESSION['user_id'], $b['id'], $txn, $amount, $method]);
            $up=$pdo->prepare("UPDATE bills SET status='Paid',paid_at=NOW() WHERE id=?");
            $up->execute([$b['id']]);
        }
        $pdo->commit();
        flash(count($bills).' due bill(s) paid in demo mode. See Payment History for receipts.');
        header('Location: history.php');
        exit;
    }
    catch(Throwable $e) {
        $pdo->rollBack();
        exit('Could not process demo payment.');
    }
}
$q=db()->prepare("SELECT COUNT(*) n,COALESCE(SUM(amount+late_fee),0) total FROM bills WHERE user_id=? AND status='Unpaid'");
$q->execute([$_SESSION['user_id']]);
$sum=$q->fetch();
app_header('Pay All Due Bills', 'My Bills');
?><div class="page-heading">
<div>
<h1>Pay All Due Bills</h1>
<p>Review the total and choose one demo payment method.</p>
</div>
</div>
<section class="panel form-panel">
<h2>
<?=
$sum['n']
?>unpaid bill(s)</h2>
<h1>
<?=
money($sum['total'])
?></h1>
<?php
if($sum['n']):
?><form method="post">
<?=
csrf_field()
?><label>Payment Method<select name="method" required>
<option value="">Choose a method</option>
<option>bKash</option>
<option>Nagad</option>
<option>Card</option>
<option>Bank Transfer</option>
</select>
</label>
<div class="demo-warning">Demo only. This will mark all unpaid sample bills as Paid without charging real money.</div>
<button class="btn">Confirm All Payments</button>
</form>
<?php
else:
?><p>There are no unpaid bills.</p>
<a class="btn" href="bills.php">Back to My Bills</a>
<?php
endif;
?></section>
<?php
app_footer();
?>