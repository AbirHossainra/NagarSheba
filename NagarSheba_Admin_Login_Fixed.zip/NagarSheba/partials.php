<?php
require_once 'config.php';
function app_header(string $title, string $active='Dashboard'): void {
    $u=current_user();
    $msg=flash();
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>
<?=
e($title)
?>| NagarSheba</title>
<link rel="stylesheet" href="assets/style.css?v=20261103-fixed">
</head>
<body class="app-body">
<header class="topbar">
<a class="brand" href="index.php">
<span class="brand-icon">☷</span>
<span>
<b>NagarSheba</b>
<small>Smart Utility System</small>
</span>
</a>
<div class="top-user">
<span class="avatar">
<?=
e(strtoupper(substr($u['full_name']??'U', 0, 1)))
?></span>
<?=
e($u['full_name']??'User')
?></div>
</header>
<div class="app-layout">
<aside class="sidebar">
<nav>
<?php
foreach(['Dashboard'=>'dashboard.php', 'My Bills'=>'bills.php', 'Payment History'=>'history.php', 'Profile'=>'profile.php', 'Settings'=>'profile.php'] as $label=>$url):
?><a class="
<?=
($active===$label?'selected':'')
?>" href="
<?=
$url
?>">
<span>
<?=
['Dashboard'=>'▦','My Bills'=>'▤','Payment History'=>'◷','Profile'=>'♙','Settings'=>'⚙'][$label]
?></span>
<?=
$label
?></a>
<?php
endforeach;
?></nav>
<a class="logout" href="logout.php">↪ &nbsp; Logout</a>
</aside>
<main class="main-content">
<?php
if($msg):
?><div class="notice">
<?=
e($msg)
?></div>
<?php
endif;
?><?php
}
function app_footer(): void {
?></main>
</div>
</body>
</html>
<?php
}
?>