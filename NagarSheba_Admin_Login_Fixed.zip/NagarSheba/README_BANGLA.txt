NAGARSHEBA - COMPLETE ADMIN + USER PROJECT
===========================================

TECHNOLOGY
PHP, MySQL, HTML, CSS. Run locally with XAMPP.

INSTALLATION (IMPORTANT: FRESH DATABASE)
1. Extract this ZIP.
2. Copy the NagarSheba folder to C:\xampp\htdocs\
   Final path: C:\xampp\htdocs\NagarSheba\index.php
3. Open XAMPP Control Panel. Start Apache and MySQL.
4. Open http://localhost/phpmyadmin
5. Select Import and import NagarSheba/database.sql.
   This SQL creates the nagarsheba database and all required tables.
   For a clean installation, use the supplied database.sql. Back up any
   existing project database first; do not mix the old schema with this one.
6. Open http://localhost/NagarSheba/setup-admin.php ONCE.
7. Admin login:
   URL: http://localhost/NagarSheba/admin-login.php
   Email: admin@nagarsheba.com
   Password: Admin@12345
8. DELETE C:\xampp\htdocs\NagarSheba\setup-admin.php after setup.
9. Open http://localhost/NagarSheba/

ADMIN PANEL FEATURES
- Overview: customer count, bills, unpaid bills, payment totals and recent transactions.
- Manage Users: create customer accounts with name, email, phone, address and password.
- Manage Bills: choose a customer and assign Electricity, Gas, Water or WiFi bill.
- Bill fields: customer/meter ID, billing month, amount, late fee and due date.
- Monthly Billing Plan: save recurring amount for a customer and utility service.
- Generate Monthly Bills: choose a month and due date; generate bills from saved plans.
- Duplicate protection: same customer + service + billing month cannot be added twice.
- Payments: record Cash, bKash, Nagad, Card or Bank Transfer payments received offline.
- Recording a payment marks that bill Paid and saves the transaction in the customer's history.
- Paid bills cannot be deleted, preserving transaction history.

USER PANEL FEATURES
- Customers can register or login.
- New accounts start with no bills. Admin assigns bills from the Admin Panel.
- User sees only their own bills, due dates, billing months and payment history.
- User can make a simulated demo payment for an unpaid bill.
- After a successful demo payment, bill status changes to Paid and a receipt is created.
- Profile page allows the customer to update their details.

HOW TO DEMONSTRATE
A. Admin creates a customer:
   Admin Login > Manage Users > Create Customer Account.
B. Admin assigns a bill:
   Manage Bills > choose customer > service > meter ID > amount > month > due date > Assign Bill.
C. Customer logs in:
   User Login > My Bills. The assigned bill should appear there.
D. Customer pays:
   Pay Now > choose demo method > Confirm Payment.
E. Admin can also record an offline payment:
   Admin Panel > Payments > choose unpaid bill > choose method > Record Payment.
   The customer's bill then becomes Paid and appears in Payment History.
F. Monthly renewal:
   Admin Panel > Manage Bills > save a Monthly Billing Plan.
   At the start of each billing month, choose the month and due date and click
   Generate Bills for This Month. Existing customer/service/month bills are skipped.

LOGIN
Admin:
  admin@nagarsheba.com
  Admin@12345
Create customer login details through Admin > Manage Users, or allow customer registration.

DATABASE CONNECTION
config.php:
  DB_HOST = localhost
  DB_NAME = nagarsheba
  DB_USER = root
  DB_PASS = blank (default XAMPP)
Change these only if your local MySQL credentials are different.

IMPORTANT
- bKash/Nagad/Card are demo payment methods. This project does NOT charge real money.
- Monthly billing generation is started manually by Admin; it is not an automatic cron job.
- For real deployment, configure HTTPS, strong admin password, backups, access controls,
  audit logs and official payment gateway APIs with server-side verification.
- Delete setup-admin.php immediately after creating the admin account.
