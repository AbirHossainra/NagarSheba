<?php
require_once 'admin-common.php';
$pdo=db();$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 check_csrf();$action=$_POST['action']??'';
 if($action==='add'){
  $uid=(int)($_POST['user_id']??0);$service=$_POST['service']??'';$customer=trim($_POST['customer_id']??'');
  $amount=(float)($_POST['amount']??-1);$fee=(float)($_POST['late_fee']??0);
  $month=$_POST['billing_month']??'';$due=$_POST['due_date']??'';
  if($uid<1||!in_array($service,['Electricity','Gas','Water','WiFi'],true)||$customer===''||$amount<0||$fee<0||!preg_match('/^\d{4}-\d{2}$/',$month)||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$due)){
   $error='Please fill in all bill details correctly.';
  }else{
   try{
    $q=$pdo->prepare("INSERT INTO bills(user_id,service,customer_id,amount,late_fee,billing_month,due_date)
      SELECT id,?,?,?,?,?,? FROM users WHERE id=? AND role='user' AND is_active=1");
    $q->execute([$service,$customer,$amount,$fee,$month,$due,$uid]);
    if($q->rowCount())flash('Bill assigned. It is now visible in the selected customer account.');
    else flash('Customer was not found or is inactive.');
    header('Location: admin-bills.php');exit;
   }catch(PDOException $ex){$error=$ex->getCode()==='23000'?'A bill for this customer, service and month already exists.':'Could not save the bill.';}
  }
 }elseif($action==='save_plan'){
  $uid=(int)($_POST['user_id']??0);$service=$_POST['service']??'';$customer=trim($_POST['customer_id']??'');
  $amount=(float)($_POST['amount']??-1);$fee=(float)($_POST['late_fee']??0);
  if($uid<1||!in_array($service,['Electricity','Gas','Water','WiFi'],true)||$customer===''||$amount<0||$fee<0)$error='Enter valid monthly plan details.';
  else{
   $q=$pdo->prepare("INSERT INTO billing_plans(user_id,service,customer_id,amount,late_fee) SELECT id,?,?,?,? FROM users WHERE id=? AND role='user' AND is_active=1 ON DUPLICATE KEY UPDATE customer_id=VALUES(customer_id),amount=VALUES(amount),late_fee=VALUES(late_fee),active=1");
   $q->execute([$service,$customer,$amount,$fee,$uid]);
   flash('Monthly billing plan saved. Generate a bill for each month when required.');
   header('Location: admin-bills.php');exit;
  }
 }elseif($action==='generate'){
  $month=$_POST['billing_month']??'';$due=$_POST['due_date']??'';
  if(!preg_match('/^\d{4}-\d{2}$/',$month)||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$due))$error='Choose a valid month and due date.';
  else{
   $plans=$pdo->query("SELECT p.* FROM billing_plans p JOIN users u ON u.id=p.user_id WHERE p.active=1 AND u.is_active=1 AND u.role='user'")->fetchAll();
   $ins=$pdo->prepare("INSERT IGNORE INTO bills(user_id,service,customer_id,amount,late_fee,billing_month,due_date) VALUES(?,?,?,?,?,?,?)");
   $made=0;foreach($plans as $p){$ins->execute([$p['user_id'],$p['service'],$p['customer_id'],$p['amount'],$p['late_fee'],$month,$due]);$made+=$ins->rowCount();}
   flash("$made new bills generated for $month. Existing bills were not duplicated.");
   header('Location: admin-bills.php');exit;
  }
 }elseif($action==='delete'){
  $id=(int)($_POST['bill_id']??0);$q=$pdo->prepare("DELETE FROM bills WHERE id=? AND status='Unpaid'");$q->execute([$id]);
  flash($q->rowCount()?'Unpaid bill deleted.':'Only unpaid bills can be deleted.');
  header('Location: admin-bills.php');exit;
 }
}
$users=$pdo->query("SELECT id,full_name,email FROM users WHERE role='user' AND is_active=1 ORDER BY full_name")->fetchAll();
$bills=$pdo->query("SELECT b.*,u.full_name,u.email FROM bills b JOIN users u ON u.id=b.user_id ORDER BY b.id DESC LIMIT 200")->fetchAll();
$plans=$pdo->query("SELECT p.*,u.full_name FROM billing_plans p JOIN users u ON u.id=p.user_id WHERE p.active=1 ORDER BY u.full_name")->fetchAll();
admin_header('Manage Utility Bills','Manage Bills');
?>
<?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
<div class="panel-grid">
<section class="panel">
 <h2>＋ Assign Individual Bill</h2><p class="muted">The bill appears in the selected user's account immediately.</p>
 <form method="post" class="form-grid"><?=csrf_field()?><input type="hidden" name="action" value="add">
 <label>Select Customer<select name="user_id" required><option value="">Choose customer</option><?php foreach($users as $u):?><option value="<?=$u['id']?>"><?=e($u['full_name'].' — '.$u['email'])?></option><?php endforeach;?></select></label>
 <label>Utility Service<select name="service"><?php foreach(['Electricity','Gas','Water','WiFi'] as $s):?><option><?=e($s)?></option><?php endforeach;?></select></label>
 <label>Customer / Meter ID<input name="customer_id" required></label>
 <label>Bill Amount (৳)<input type="number" name="amount" min="0" step=".01" required></label>
 <label>Late Fee (৳)<input type="number" name="late_fee" min="0" step=".01" value="0"></label>
 <label>Billing Month<input type="month" name="billing_month" value="<?=date('Y-m')?>" required></label>
 <label>Due Date<input type="date" name="due_date" required></label>
 <button class="btn" type="submit">Assign Bill to Customer</button></form>
</section>
<section class="panel">
 <h2>↻ Monthly Billing Plan</h2><p class="muted">Save a customer's recurring utility amount once. Generate each month's bill when ready.</p>
 <form method="post" class="form-grid"><?=csrf_field()?><input type="hidden" name="action" value="save_plan">
 <label>Customer<select name="user_id" required><option value="">Choose customer</option><?php foreach($users as $u):?><option value="<?=$u['id']?>"><?=e($u['full_name'].' — '.$u['email'])?></option><?php endforeach;?></select></label>
 <label>Utility Service<select name="service"><?php foreach(['Electricity','Gas','Water','WiFi'] as $s):?><option><?=e($s)?></option><?php endforeach;?></select></label>
 <label>Customer / Meter ID<input name="customer_id" required></label>
 <label>Monthly Amount (৳)<input type="number" name="amount" min="0" step=".01" required></label>
 <label>Late Fee (৳)<input type="number" name="late_fee" min="0" step=".01" value="0"></label>
 <button class="btn" type="submit">Save Monthly Plan</button></form>
 <hr><h3>Generate Monthly Bills</h3>
 <form method="post" class="form-grid"><?=csrf_field()?><input type="hidden" name="action" value="generate">
 <label>Billing Month<input type="month" name="billing_month" value="<?=date('Y-m')?>" required></label>
 <label>Due Date<input type="date" name="due_date" required></label>
 <button class="btn" type="submit">Generate Bills for This Month</button></form>
 <p class="table-note">Admin starts monthly generation manually. Duplicate bills are blocked by the database.</p>
</section></div>
<section class="panel"><div class="panel-title"><h2>Saved Monthly Plans</h2><span class="muted"><?=count($plans)?> active plans</span></div>
<div class="table-wrap"><table><thead><tr><th>Customer</th><th>Service</th><th>Meter ID</th><th>Monthly Amount</th><th>Late Fee</th></tr></thead><tbody>
<?php foreach($plans as $p):?><tr><td><?=e($p['full_name'])?></td><td><?=e($p['service'])?></td><td><?=e($p['customer_id'])?></td><td><?=money($p['amount'])?></td><td><?=money($p['late_fee'])?></td></tr><?php endforeach;?>
<?php if(!$plans):?><tr><td colspan="5" class="empty">No monthly plans saved yet.</td></tr><?php endif;?></tbody></table></div></section>
<section class="panel"><div class="panel-title"><h2>All Customer Bills</h2><span class="muted"><?=count($bills)?> latest records</span></div><div class="table-wrap"><table><thead><tr><th>Customer</th><th>Service</th><th>Billing Month</th><th>Amount</th><th>Due Date</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($bills as $b):?><tr><td><?=e($b['full_name'])?><small><?=e($b['email'])?></small></td><td><?=e($b['service'])?><small><?=e($b['customer_id'])?></small></td><td><?=e($b['billing_month'])?></td><td><?=money((float)$b['amount']+(float)$b['late_fee'])?></td><td><?=e($b['due_date'])?></td><td><?=e($b['status'])?></td><td><?php if($b['status']==='Unpaid'):?><form method="post" onsubmit="return confirm('Delete this unpaid bill?')"><?=csrf_field()?><input type="hidden" name="action" value="delete"><input type="hidden" name="bill_id" value="<?=$b['id']?>"><button class="btn small" type="submit">Delete</button></form><?php else:?>—<?php endif;?></td></tr><?php endforeach;?>
<?php if(!$bills):?><tr><td colspan="7" class="empty">No bills created yet.</td></tr><?php endif;?></tbody></table></div></section>
<?php admin_footer(); ?>
