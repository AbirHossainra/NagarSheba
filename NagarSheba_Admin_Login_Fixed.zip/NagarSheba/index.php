<?php
require_once 'config.php';
$user=current_user();
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NagarSheba | Smart Utility System</title>
<link rel="stylesheet" href="assets/style.css?v=20261103-fixed">
</head>
<body class="landing">
<section class="hero wrap">
<div class="hero-copy">
<span class="eyebrow">Smart Utility Management</span>
<h1>Manage Your Bills<br>Smarter &amp; Easier</h1>
<p>One-stop secure payment and tracking portal for all your Electricity, Gas, Water &amp; WiFi bills. Say goodbye to late fees.</p>
<p class="bangla">আপনার প্রয়োজনীয় ইউটিলিটি বিল এখন এক জায়গায় সহজে পরিশোধ করুন।</p>
<a class="btn" href="
<?=
logged_in()?(is_admin()?'admin-dashboard.php':'dashboard.php'):'login.php'
?>">Manage Bills <span>→</span>
</a>
</div>
<div class="phone">
<div class="phone-top">
<span>9:41</span>
<span>●</span>
</div>
<div class="phone-name">Smart Pay<br>
<b>
<?=
e($user['full_name']??'Ahsan Habib')
?></b>
</div>
<div class="phone-total">
<small>Total Due Amount</small>
<strong>
<?=
logged_in() ? money((db()->query("SELECT COALESCE(SUM(amount),0) FROM bills WHERE user_id=".(int)$_SESSION['user_id']." AND status='Unpaid'")->fetchColumn())) : '৳2,500'
?></strong>
<small>4 Active Bills</small>
</div>
<b class="tiny-label">PAY BILLS</b>
<div class="phone-services">
<span>ϟ<br>Power</span>
<span>♨<br>Gas</span>
<span>♢<br>Water</span>
</div>
<a href="
<?=
logged_in()?'bills.php':'login.php'
?>" class="phone-pay">Pay Now</a>
</div>
</section>
<nav class="navbar wrap">
<a class="brand" href="index.php">
<span class="brand-icon">☷</span>
<span>
<b>NagarSheba</b>
<small>Smart Utility System</small>
</span>
</a>
<div class="navlinks">
<a class="active" href="index.php">Home</a>
<a href="#about">About</a>
<a href="#services">Services</a>
<a href="#contact">Contact</a>
</div>
<div>
<?php if(logged_in()): ?>
<a class="btn small" href="<?=is_admin()?'admin-dashboard.php':'dashboard.php'?>">Dashboard</a>
<a class="btn small light" href="logout.php">Logout</a>
<?php else: ?>
<a class="btn small" href="login.php">User Login</a>
<a class="btn small light" href="register.php">Register</a>
<a class="btn small secondary" href="admin-login.php">Admin Login</a>
<?php endif; ?></div>
</nav>
<section class="wrap services-section" id="services">
<h2>Our Supported Utility Services</h2>
<div class="service-grid">
<div class="service-card">
<i class="electric">ϟ</i>
<h3>Electricity</h3>
<p>Pay your power utility bills instantly with auto-updated billing schedules.</p>
</div>
<div class="service-card">
<i class="gas">♨</i>
<h3>Gas</h3>
<p>Manage gas pipeline connections and pay standard monthly tariffs easily.</p>
</div>
<div class="service-card">
<i class="water">♢</i>
<h3>Water</h3>
<p>Secure and clean portal linked directly to your municipal water supplier.</p>
</div>
<div class="service-card">
<i class="wifi">⌁</i>
<h3>WiFi</h3>
<p>Manage ISP plans and internet bills hassle-free.</p>
</div>
</div>
</section>
<section class="wrap about" id="about">
<h2>All your utility bills in one place</h2>
<p>Create an account to view due bills, make a demo payment and keep your receipts organized.</p>
</section>
<footer id="contact">NagarSheba • Smart Utility System <span>Contact: support@nagarsheba.local</span>
</footer>
</body>
</html>
