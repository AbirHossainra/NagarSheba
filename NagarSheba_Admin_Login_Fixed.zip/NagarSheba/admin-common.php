<?php
require_once 'config.php';
require_admin();
function admin_header(string $title, string $active): void {
    $u=current_user(); $msg=flash();
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($title)?> | NagarSheba Admin</title><link rel="stylesheet" href="assets/style.css?v=20261106-admin"></head><body class="app-body"><header class="topbar"><a class="brand" href="admin-dashboard.php"><span class="brand-icon">☷</span><span><b>NagarSheba</b><small>Admin Control Panel</small></span></a><div class="top-user">Admin: <?=e($u['full_name']??'Administrator')?></div></header><div class="app-layout"><aside class="sidebar"><nav><?php foreach(['Overview'=>'admin-dashboard.php','Manage Users'=>'admin-users.php','Manage Bills'=>'admin-bills.php','Payments'=>'admin-payments.php'] as $label=>$url): ?><a class="<?=$active===$label?'selected':''?>" href="<?=$url?>"><?=e($label)?></a><?php endforeach; ?></nav><a class="logout" href="logout.php">↪ &nbsp; Logout</a><p class="muted" style="padding:12px">Admin access only</p></aside><main class="main-content"><?php if($msg): ?><div class="notice"><?=e($msg)?></div><?php endif; ?><div class="page-heading"><div><h1><?=e($title)?></h1><p>Manage NagarSheba utility services and records</p></div><a class="btn" href="dashboard.php">User View</a></div>
<?php }
function admin_footer(): void { ?></main></div></body></html><?php }
