<?php
require_once 'admin-common.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 check_csrf();
 $name=trim($_POST['full_name']??'');$email=strtolower(trim($_POST['email']??''));
 $phone=trim($_POST['phone']??'');$address=trim($_POST['address']??'');$pass=$_POST['password']??'';
 if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<6){
  $error='Enter a name, valid email and password with at least 6 characters.';
 }else{
  try{
   $q=db()->prepare("INSERT INTO users(full_name,email,phone,address,password_hash,role,is_active) VALUES(?,?,?,?,?,'user',1)");
   $q->execute([$name,$email,$phone,$address,password_hash($pass,PASSWORD_DEFAULT)]);
   flash('Customer account created successfully. The customer can now login.');
   header('Location: admin-users.php');exit;
  }catch(PDOException $ex){$error=$ex->getCode()==='23000'?'This email address is already registered.':'Could not create the account. Please check the database.';}
 }
}
$users=db()->query("SELECT u.id,u.full_name,u.email,u.phone,u.address,u.created_at,u.is_active,
 (SELECT COUNT(*) FROM bills b WHERE b.user_id=u.id) bill_count,
 (SELECT COUNT(*) FROM bills b WHERE b.user_id=u.id AND b.status='Unpaid') unpaid_count
 FROM users u WHERE u.role='user' ORDER BY u.id DESC")->fetchAll();
admin_header('Manage Customers','Manage Users');
?>
<section class="panel">
 <h2>＋ Create Customer Account</h2>
 <p class="muted">Create the customer's login first. Assign their utility bills from Manage Bills.</p>
 <?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
 <form method="post" class="form-grid">
  <?=csrf_field()?>
  <label>Full Name<input name="full_name" required></label>
  <label>Email Address<input type="email" name="email" required></label>
  <label>Phone Number<input name="phone"></label>
  <label>Address<input name="address"></label>
  <label>Temporary Password<input type="text" name="password" minlength="6" required></label>
  <button class="btn" type="submit">Create Customer Account</button>
 </form>
</section>
<section class="panel">
 <div class="panel-title"><h2>Customer Accounts</h2><span class="muted"><?=count($users)?> customers</span></div>
 <div class="table-wrap"><table><thead><tr><th>ID</th><th>Customer</th><th>Contact</th><th>Address</th><th>Bills</th><th>Unpaid</th><th>Joined</th></tr></thead><tbody>
 <?php foreach($users as $u):?><tr><td>#<?=$u['id']?></td><td><b><?=e($u['full_name'])?></b><small><?=$u['is_active']?'Active':'Inactive'?></small></td><td><?=e($u['email'])?><small><?=e($u['phone'])?></small></td><td><?=e($u['address'])?></td><td><?=$u['bill_count']?></td><td class="orange"><?=$u['unpaid_count']?></td><td><?=e($u['created_at'])?></td></tr><?php endforeach;?>
 <?php if(!$users):?><tr><td colspan="7" class="empty">No customer accounts yet. Create the first one above.</td></tr><?php endif;?>
 </tbody></table></div>
</section>
<?php admin_footer(); ?>
