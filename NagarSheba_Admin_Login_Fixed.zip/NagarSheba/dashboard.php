<?php
require_once 'partials.php';
require_login();
$uid=(int)$_SESSION['user_id'];
$u=current_user();
$q=db()->prepare("SELECT COUNT(*) total, SUM(status='Paid') paid, SUM(status='Unpaid') unpaid, COALESCE(SUM(amount+late_fee),0) amount FROM bills WHERE user_id=?");
$q->execute([$uid]);
$m=$q->fetch();
$q=db()->prepare("SELECT service,COUNT(*) total,SUM(status='Paid') paid,SUM(status='Unpaid') unpaid,SUM(amount+late_fee) amount FROM bills WHERE user_id=? GROUP BY service ORDER BY FIELD(service,'Electricity','Gas','Water','WiFi')");
$q->execute([$uid]);
$rows=$q->fetchAll();
app_header('Dashboard', 'Dashboard');
?><div class="page-heading">
<div>
<h1>Welcome,
<?=
e($u['full_name'] ?? 'User')
?>👋</h1>
<p>Here is your dashboard overview</p>
</div>
<a class="btn" href="bills.php">View My Bills →</a>
</div>
<div class="stats">
<div class="stat">
<small>Total Bills</small>
<strong>
<?=
(int)$m['total']
?></strong>
<span>Active utility bills</span>
</div>
<div class="stat">
<small>Paid Bills</small>
<strong class="green">
<?=
(int)$m['paid']
?></strong>
<span>Successfully paid</span>
</div>
<div class="stat">
<small>Unpaid Bills</small>
<strong class="orange">
<?=
(int)$m['unpaid']
?></strong>
<span>Need your attention</span>
</div>
<div class="stat">
<small>Total Amount</small>
<strong>
<?=
money($m['amount'])
?></strong>
<span>All listed bills</span>
</div>
</div>
<div class="panel-grid">
<section class="panel">
<div class="panel-title">
<h2>User Details</h2>
<a href="profile.php">Edit profile</a>
</div>
<dl class="details">
<dt>Name</dt>
<dd>
<?=
e($u['full_name'] ?? 'User')
?></dd>
<dt>Email</dt>
<dd>
<?=
e($u['email'] ?? '')
?></dd>
<dt>Phone</dt>
<dd>
<?=
e($u['phone'] ?? '')
?></dd>
<dt>Address</dt>
<dd>
<?=
e($u['address'] ?? '')
?></dd>
<dt>Join Date</dt>
<dd>
<?=
date('d F Y', strtotime($u['created_at'] ?? 'now'))
?></dd>
</dl>
</section>
<section class="panel">
<div class="panel-title">
<h2>Billing Overview</h2>
<a href="bills.php">See all</a>
</div>
<div class="table-wrap">
<table>
<thead>
<tr>
<th>Utility</th>
<th>Total Bills</th>
<th>Paid</th>
<th>Unpaid</th>
<th>Amount</th>
</tr>
</thead>
<tbody>
<?php
foreach($rows as $r):
?><tr>
<td>
<?=
e($r['service'])
?></td>
<td>
<?=
$r['total']
?></td>
<td class="green">
<?=
$r['paid']
?></td>
<td class="orange">
<?=
$r['unpaid']
?></td>
<td>
<?=
money($r['amount'])
?></td>
</tr>
<?php
endforeach;
?></tbody>
</table>
</div>
</section>
</div>
<?php
app_footer();
?>