<?php
require_once __DIR__ . '/config.php';

$error = '';
$info = '';

// If an admin is already signed in, go straight to the admin dashboard.
if (logged_in() && is_admin()) {
    header('Location: admin-dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    try {
        $stmt = db()->prepare("SELECT id, password_hash, role, is_active FROM users WHERE LOWER(email) = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = 'এই email দিয়ে Admin account পাওয়া যায়নি। আগে setup-admin.php একবার চালাও।';
        } elseif (($user['role'] ?? '') !== 'admin') {
            $error = 'এই account টি Admin নয়। Admin account দিয়ে চেষ্টা করো।';
        } elseif ((int)($user['is_active'] ?? 0) !== 1) {
            $error = 'Admin account inactive আছে। setup-admin.php চালিয়ে আবার চেষ্টা করো।';
        } elseif (!password_verify($password, (string)$user['password_hash'])) {
            $error = 'Password ভুল হয়েছে। Default password reset করতে setup-admin.php চালাও।';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['role'] = 'admin';
            header('Location: admin-dashboard.php');
            exit;
        }
    } catch (Throwable $exception) {
        $error = 'Database connection/table error: ' . $exception->getMessage();
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login | NagarSheba</title>
<link rel="stylesheet" href="assets/style.css?v=20261110-adminfix">
</head>
<body class="auth-body">
<a class="auth-brand" href="index.php">NagarSheba <small>Admin Panel</small></a>
<main class="auth-card">
<h1>Admin Login</h1>
<p class="muted center">Sign in to manage NagarSheba</p>
<?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
<form method="post" autocomplete="on">
<?= csrf_field() ?>
<label>Admin Email<input type="email" name="email" value="<?= e($_POST['email'] ?? 'admin@nagarsheba.com') ?>" required autocomplete="username"></label>
<label>Password<input type="password" name="password" required autocomplete="current-password"></label>
<button class="btn full" type="submit">Login as Admin</button>
</form>
<p class="center" style="margin-top:16px"><a href="setup-admin.php">Reset / Set default Admin password</a></p>
<p class="center"><a href="login.php">User Login</a></p>
</main>
</body>
</html>
