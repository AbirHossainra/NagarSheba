<?php
require_once 'partials.php';
require_login();
$q=db()->prepare("SELECT * FROM bills WHERE id=? AND user_id=?");
$q->execute([(int)($_GET['id']??0), $_SESSION['user_id']]);
$bill=$q->fetch();
if(!$bill) {
    http_response_code(404);
    exit('Bill not found.');
}
if($bill['status']==='Paid') {
    header('Location: history.php');
    exit;
}
app_header('Pay '.$bill['service'].' Bill', 'My Bills');
?><div class="page-heading">
<div>
<h1>Pay
<?=
e($bill['service'])
?>Bill</h1>
<p>Review your invoice and select a payment method.</p>
</div>
<a class="text-link" href="bills.php">← Back to My Bills</a>
</div>
<div class="payment-layout">
<section class="panel invoice">
<h2>
<?=
e($bill['service'])
?>Bill</h2>
<p class="muted">Customer ID:
<?=
e($bill['customer_id'])
?></p>
<div class="invoice-lines">
<div>
<span>Billing Period</span>
<b>
<?=
date('F Y')
?></b>
</div>
<div>
<span>Bill Amount</span>
<b>
<?=
money($bill['amount'])
?></b>
</div>
<div>
<span>Due Date</span>
<b>
<?=
date('d M Y', strtotime($bill['due_date']))
?></b>
</div>
<div>
<span>Late Fee</span>
<b>
<?=
money($bill['late_fee'])
?></b>
</div>
</div>
<div class="invoice-total">
<span>Total Amount</span>
<strong>
<?=
money($bill['amount']+$bill['late_fee'])
?></strong>
</div>
</section>
<section class="panel">
<h2>Select Payment Method</h2>
<form action="process-payment.php" method="post">
<?=
csrf_field()
?><input type="hidden" name="bill_id" value="
<?=
$bill['id']
?>">
<div class="method-list">
<label class="method">
<input type="radio" name="method" value="bKash" required>
<span class="method-icon pink">b</span>
<b>bKash Mobile Wallet</b>
</label>
<label class="method">
<input type="radio" name="method" value="Nagad">
<span class="method-icon orange-bg">N</span>
<b>Nagad Wallet</b>
</label>
<label class="method">
<input type="radio" name="method" value="Card">
<span class="method-icon blue-bg">▣</span>
<b>Credit or Debit Card</b>
</label>
<label class="method">
<input type="radio" name="method" value="Bank Transfer">
<span class="method-icon green-bg">⌂</span>
<b>Bank Transfer</b>
</label>
</div>
<div class="demo-warning">Demo mode: no real money will be charged. Confirming will mark this sample bill as Paid.</div>
<button class="btn full">Confirm Payment</button>
</form>
</section>
</div>
<?php
app_footer();
?>