<?php
require_once 'config.php';
require_login();
if($_SERVER['REQUEST_METHOD']!=='POST') {
    header('Location: bills.php');
    exit;
}
check_csrf();
$id=(int)($_POST['bill_id']??0);
$method=$_POST['method']??'';
$allowed=['bKash','Nagad','Card','Bank Transfer'];
if(!in_array($method, $allowed, true)) {
    flash('Please select a payment method.');
    header('Location: bills.php');
    exit;
}
try {
    $pdo=db();
    $pdo->beginTransaction();
    $q=$pdo->prepare("SELECT * FROM bills WHERE id=? AND user_id=? FOR UPDATE");
    $q->execute([$id, $_SESSION['user_id']]);
    $bill=$q->fetch();
    if(!$bill||$bill['status']==='Paid') {
        $pdo->rollBack();
        flash('This bill is not available for payment.');
        header('Location: bills.php');
        exit;
    }
    $txn='NS'.date('YmdHis').random_int(100, 999);
    $amount=(float)$bill['amount']+(float)$bill['late_fee'];
    $q=$pdo->prepare("INSERT INTO payments(user_id,bill_id,transaction_id,amount,method,status) VALUES(?,?,?,?,?,'Successful')");
    $q->execute([$_SESSION['user_id'], $id, $txn, $amount, $method]);
    $pid=(int)$pdo->lastInsertId();
    $q=$pdo->prepare("UPDATE bills SET status='Paid',paid_at=NOW() WHERE id=?");
    $q->execute([$id]);
    $pdo->commit();
    header('Location: receipt.php?id='.$pid);
    exit;
}
catch(Throwable $e) {
    if(db()->inTransaction())db()->rollBack();
    http_response_code(500);
    exit('Payment could not be completed. Please check database setup.');
}
