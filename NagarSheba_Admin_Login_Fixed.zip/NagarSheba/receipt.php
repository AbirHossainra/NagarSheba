<?php
require_once 'partials.php';
require_login();
$q=db()->prepare("SELECT p.*,b.service,b.customer_id FROM payments p JOIN bills b ON b.id=p.bill_id WHERE p.id=? AND p.user_id=?");
$q->execute([(int)($_GET['id']??0), $_SESSION['user_id']]);
$p=$q->fetch();
if(!$p) {
    http_response_code(404);
    exit('Receipt not found.');
}
app_header('Payment Receipt', 'Payment History');
?><div class="success-wrap">
<div class="success-mark">✓</div>
<h1>Payment Successful!</h1>
<p class="muted">Your payment has been completed successfully.</p>
<section class="receipt">
<h2>Payment Receipt</h2>
<div>
<span>Transaction ID</span>
<b>
<?=
e($p['transaction_id'])
?></b>
</div>
<div>
<span>Utility Bill</span>
<b>
<?=
e($p['service'])
?>Bill</b>
</div>
<div>
<span>Customer ID</span>
<b>
<?=
e($p['customer_id'])
?></b>
</div>
<div>
<span>Payment Method</span>
<b>
<?=
e($p['method'])
?></b>
</div>
<div>
<span>Amount Paid</span>
<b>
<?=
money($p['amount'])
?></b>
</div>
<div>
<span>Payment Date</span>
<b>
<?=
date('d M Y, h:i A', strtotime($p['paid_at']))
?></b>
</div>
<div>
<span>Status</span>
<b class="green">
<?=
e($p['status'])
?></b>
</div>
<button class="btn full no-print" onclick="window.print()">Download / Print Receipt</button>
</section>
<a class="btn" href="dashboard.php">Back to Dashboard</a>
</div>
<?php
app_footer();
?>