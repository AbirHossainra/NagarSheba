<?php
require_once __DIR__ . '/config.php';

// Run this page once to create/reset the demo administrator.
// Delete this file after successful setup on a publicly hosted server.
$email = 'admin@nagarsheba.com';
$password = 'Admin@12345';

try {
    $pdo = db();
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare('SELECT id FROM users WHERE LOWER(email) = ? LIMIT 1');
    $stmt->execute([$email]);
    $id = $stmt->fetchColumn();

    if ($id) {
        $update = $pdo->prepare("UPDATE users SET full_name = ?, password_hash = ?, role = 'admin', is_active = 1 WHERE id = ?");
        $update->execute(['NagarSheba Admin', $hash, (int)$id]);
        $message = 'আগের Admin account reset করা হয়েছে।';
    } else {
        $insert = $pdo->prepare("INSERT INTO users (full_name, email, password_hash, role, is_active) VALUES (?, ?, ?, 'admin', 1)");
        $insert->execute(['NagarSheba Admin', $email, $hash]);
        $message = 'নতুন Admin account তৈরি হয়েছে।';
    }
} catch (Throwable $exception) {
    http_response_code(500);
    exit('Admin setup failed: ' . htmlspecialchars($exception->getMessage(), ENT_QUOTES, 'UTF-8'));
}
?>
<!doctype html>
<html lang="bn">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Setup | NagarSheba</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth-body">
<main class="auth-card">
<h1>Admin Setup Successful</h1>
<p><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
<p><b>Email:</b> <?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?></p>
<p><b>Password:</b> <?= htmlspecialchars($password, ENT_QUOTES, 'UTF-8') ?></p>
<p><a class="btn full" href="admin-login.php">Go to Admin Login</a></p>
<p class="muted">Local demo project হলে login পরীক্ষা করার পর setup-admin.php ফাইলটি delete করে দাও।</p>
</main>
</body></html>
