<?php
require_once 'config.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    $name=trim($_POST['full_name']??'');
    $email=strtolower(trim($_POST['email']??''));
    $phone=trim($_POST['phone']??'');
    $address=trim($_POST['address']??'');
    $pass=$_POST['password']??'';
    $confirm=$_POST['confirm_password']??'';
    if(!$name||!filter_var($email, FILTER_VALIDATE_EMAIL)||strlen($pass)<6) $error='Please enter valid details. Password must be at least 6 characters.';
    elseif($pass!==$confirm) $error='Passwords do not match.';
    else {
        try {
            $q=db()->prepare("INSERT INTO users(full_name,email,phone,address,password_hash) VALUES(?,?,?,?,?)");
            $q->execute([$name, $email, $phone, $address, password_hash($pass, PASSWORD_DEFAULT)]);
            $uid=(int)db()->lastInsertId();
            // New accounts start with an empty bill list. Admin assigns bills from Manage Bills.
            session_regenerate_id(true);
            $_SESSION['user_id']=$uid;
            $_SESSION['role']='user';
            header('Location: dashboard.php');
            exit;
        }
        catch(PDOException $ex) {
            $error=$ex->getCode()==='23000'?'This email is already registered. Please log in.':'Database error. Check setup and try again.';
        }
    }
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Create Account | NagarSheba</title>
<link rel="stylesheet" href="assets/style.css?v=20261103-fixed">
</head>
<body class="auth-body">
<a class="auth-brand" href="index.php">NagarSheba <small>Smart Utility System</small>
</a>
<main class="auth-card">
<h1>Create Your Account</h1>
<p class="muted center">Register to get started with NagarSheba</p>
<?php
if($error):
?><div class="alert">
<?=
e($error)
?></div>
<?php
endif;
?><form method="post">
<?=
csrf_field()
?><label>Full Name<input name="full_name" placeholder="Enter your name" required value="
<?=
e($_POST['full_name']??'')
?>">
</label>
<label>Email Address<input type="email" name="email" placeholder="Enter your email" required value="
<?=
e($_POST['email']??'')
?>">
</label>
<label>Phone Number<input name="phone" placeholder="Enter your phone number">
</label>
<label>Address<input name="address" placeholder="Enter your address">
</label>
<div class="two-col">
<label>Password<input type="password" name="password" placeholder="Create a password" minlength="6" required>
</label>
<label>Confirm Password<input type="password" name="confirm_password" placeholder="Confirm your password" required>
</label>
</div>
<button class="btn full">Register</button>
</form>
<p class="center muted">Already have an account? <a href="login.php">Login here</a>
</p>
</main>
</body>
</html>
