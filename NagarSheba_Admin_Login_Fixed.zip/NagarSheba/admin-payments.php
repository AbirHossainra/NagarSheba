<?php
require_once 'admin-common.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 check_csrf();$billId=(int)($_POST['bill_id']??0);$method=$_POST['method']??'';$note=trim($_POST['note']??'');
 if(!in_array($method,['Cash','bKash','Nagad','Card','Bank Transfer'],true))$error='Select a valid payment method.';
 else{
  try{
   $pdo=db();$pdo->beginTransaction();
   $q=$pdo->prepare("SELECT * FROM bills WHERE id=? AND status='Unpaid' FOR UPDATE");$q->execute([$billId]);$bill=$q->fetch();
   if(!$bill){$pdo->rollBack();$error='Bill not found or it has already been paid.';}
   else{
    $txn='NSA'.date('YmdHis').random_int(1000,9999);$amount=(float)$bill['amount']+(float)$bill['late_fee'];
    $q=$pdo->prepare("INSERT INTO payments(user_id,bill_id,transaction_id,amount,method,note,status) VALUES(?,?,?,?,?,?,'Successful')");
    $q->execute([$bill['user_id'],$billId,$txn,$amount,$method,$note?:'Payment received and recorded by admin']);
    $pdo->prepare("UPDATE bills SET status='Paid',paid_at=NOW() WHERE id=?")->execute([$billId]);
    $pdo->commit();flash('Payment recorded successfully. The customer bill is now marked Paid.');
    header('Location: admin-payments.php');exit;
   }
  }catch(Throwable $ex){if(db()->inTransaction())db()->rollBack();$error='Could not record payment. Please check the bill and database.';}
 }
}
$unpaid=db()->query("SELECT b.id,b.service,b.billing_month,b.amount,b.late_fee,b.due_date,u.full_name,u.email FROM bills b JOIN users u ON u.id=b.user_id WHERE b.status='Unpaid' ORDER BY b.due_date")->fetchAll();
$rows=db()->query("SELECT p.*,u.full_name,u.email,b.service,b.billing_month FROM payments p JOIN users u ON u.id=p.user_id JOIN bills b ON b.id=p.bill_id ORDER BY p.id DESC")->fetchAll();
admin_header('Payments','Payments');
?>
<div class="panel-grid">
<section class="panel"><h2>＋ Record a Payment</h2><p class="muted">For payments received at the office or through an external channel. Only record money actually received.</p>
<?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
<form method="post" class="form-grid"><?=csrf_field()?>
<label>Select Unpaid Bill<select name="bill_id" required><option value="">Choose customer bill</option><?php foreach($unpaid as $b):?><option value="<?=$b['id']?>"><?=e($b['full_name'].' · '.$b['service'].' · '.$b['billing_month'].' · '.money((float)$b['amount']+(float)$b['late_fee']))?></option><?php endforeach;?></select></label>
<label>Payment Method<select name="method"><?php foreach(['Cash','bKash','Nagad','Card','Bank Transfer'] as $m):?><option><?=e($m)?></option><?php endforeach;?></select></label>
<label>Transaction Reference / Note<input name="note" placeholder="Optional reference number"></label>
<button class="btn" type="submit">Record Payment & Mark Bill Paid</button></form>
</section>
<section class="panel"><h2>Payment process</h2><ol><li>Choose the correct unpaid customer bill.</li><li>Select how the payment was received.</li><li>Submit the payment record.</li><li>The bill becomes Paid in the customer's account.</li><li>The transaction appears in the customer's Payment History.</li></ol><p class="table-note">This is a demo payment record. It does not connect to a live bKash/Nagad/card gateway or charge money.</p></section>
</div>
<section class="panel"><div class="panel-title"><h2>All Payment Transactions</h2><span class="muted"><?=count($rows)?> records</span></div><div class="table-wrap"><table><thead><tr><th>Transaction ID</th><th>Customer</th><th>Service</th><th>Month</th><th>Amount</th><th>Method</th><th>Note</th><th>Date</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td><?=e($r['transaction_id'])?></td><td><?=e($r['full_name'])?><small><?=e($r['email'])?></small></td><td><?=e($r['service'])?></td><td><?=e($r['billing_month'])?></td><td><?=money($r['amount'])?></td><td><?=e($r['method'])?></td><td><?=e($r['note'])?></td><td><?=e($r['paid_at'])?></td></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="8" class="empty">No payment records yet.</td></tr><?php endif;?></tbody></table></div></section>
<?php admin_footer(); ?>
