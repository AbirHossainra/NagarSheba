NAGARSHEBA LOGIN + DASHBOARD FIX
================================

এই ZIP-এ Login navigation ও User Dashboard-এর undefined array key warning fix করা হয়েছে।

SETUP:
1. পুরোনো C:\\xampp\\htdocs\\NagarSheba folder backup/rename করো।
2. এই ZIP extract করে নতুন NagarSheba folder C:\\xampp\\htdocs\\ এর মধ্যে রাখো।
3. Apache ও MySQL Start করো।
4. আগের database nagarsheba থাকলে সেটি delete কোরো না; এই update একই database schema ব্যবহার করে।
5. Browser cache refresh: Ctrl + F5.

PAGES:
Homepage: http://localhost/NagarSheba/index.php
User Login: http://localhost/NagarSheba/login.php
User Register: http://localhost/NagarSheba/register.php
Admin Login: http://localhost/NagarSheba/admin-login.php

IMPORTANT:
- Existing database-এ users table-এর full_name, email, phone, address, password_hash, role, is_active, created_at columns থাকতে হবে।
- নতুন database import করার দরকার নেই যদি আগের NagarSheba database ঠিক থাকে।
- Admin login করতে Admin Login link ব্যবহার করো। User login page-এ admin account ঢুকবে না।
- যদি Dashboard-এ আগের warning দেখা যায়, নিশ্চিত করো নতুন ZIP-এর dashboard.php এবং config.php পুরোনো folder-এর উপর replace হয়েছে এবং Ctrl+F5 করেছ।
- Admin setup credentials আগের setup-admin.php script অনুযায়ী: admin@nagarsheba.com / Admin@12345 (শুধু যদি setup script দিয়ে ওই account তৈরি করা হয়ে থাকে)।
