<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'nagarsheba');
define('DB_USER', 'root');
define('DB_PASS', '');
if (session_status() === PHP_SESSION_NONE) session_start();
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO( 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC] );
    }
    return $pdo;
}
function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function logged_in(): bool {
    return !empty($_SESSION['user_id']);
}
function require_login(): void {
    if (!logged_in()) {
        header('Location: login.php');
        exit;
    }
    if (is_admin()) {
        header('Location: admin-dashboard.php');
        exit;
    }
    // Clear stale sessions if the account was deleted or disabled.
    $u = current_user();
    if (!$u || (int)($u['is_active'] ?? 1) !== 1) {
        $_SESSION = [];
        session_regenerate_id(true);
        header('Location: login.php?session=expired');
        exit;
    }
}
function is_admin(): bool {
    return logged_in() && (($_SESSION['role'] ?? '') === 'admin');
}
function require_admin(): void {
    if (!is_admin()) {
        header('Location: admin-login.php');
        exit;
    }
}
function current_user(): array {
    $empty = ['id'=>0, 'full_name'=>'User', 'email'=>'', 'phone'=>'', 'address'=>'', 'created_at'=>date('Y-m-d H:i:s'), 'role'=>'user', 'is_active'=>1];
    if (!logged_in()) return $empty;
    try {
        $q=db()->prepare("SELECT id, full_name, email, phone, address, created_at, role, is_active FROM users WHERE id=? LIMIT 1");
        $q->execute([(int)$_SESSION['user_id']]);
        $row=$q->fetch();
        return $row ? array_merge($empty, $row) : [];
    } catch (Throwable $e) {
        return $empty;
    }
}
function money($amount): string {
    return '৳'.number_format((float)$amount, 2);
}
function flash($message=null): ?string {
    if ($message !== null) {
        $_SESSION['flash']=$message;
        return null;
    }
    $m=$_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $m;
}
function csrf_field(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'">';
}
function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('Invalid request. Please go back and try again.');
    }
}
