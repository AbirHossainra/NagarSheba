<?php
require_once 'partials.php';
require_login();
$q=db()->prepare("SELECT * FROM bills WHERE user_id=? ORDER BY FIELD(status,'Unpaid','Paid'),due_date");
$q->execute([$_SESSION['user_id']]);
$bills=$q->fetchAll();
$due=array_filter($bills, fn($b)=>$b['status']==='Unpaid');
app_header('My Bills', 'My Bills');
?><div class="page-heading">
<div>
<h1>My Bills</h1>
<p>Easily monitor and clear your municipal utility obligations online.</p>
</div>
<?php
if($due):
?><a class="btn" href="pay-all.php">Pay All Due Bills</a>
<?php
endif;
?></div>
<section class="panel">
<div class="panel-title">
<h2>Manage Your Utility Bills</h2>
<span class="muted">
<?=
count($bills)
?>active subscriptions</span>
</div>
<div class="table-wrap">
<table class="bill-table">
<thead>
<tr>
<th>Utility Service</th>
<th>Billing Month</th>
<th>Amount</th>
<th>Due Date / Date</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php
foreach($bills as $b):
?><tr>
<td>
<b>
<?=
e($b['service'])
?>Bill</b>
<small>Customer ID:
<?=
e($b['customer_id'])
?></small>
</td>
<td><?=e($b['billing_month'])?></td>
<td>
<?=money((float)$b['amount']+(float)$b['late_fee'])
?></td>
<td>
<?=
date('d M Y', strtotime($b['due_date']))
?></td>
<td>
<span class="status
<?=
strtolower($b['status'])
?>">
<?=
e($b['status'])
?></span>
</td>
<td>
<?php
if($b['status']==='Unpaid'):
?><a class="btn small" href="pay.php?id=
<?=
$b['id']
?>">Pay Now</a>
<?php
else:
?><a class="text-link" href="history.php">View</a>
<?php
endif;
?></td>
</tr>
<?php
endforeach;
?></tbody>
</table>
</div>
<p class="table-note">Showing
<?=
count($bills)
?>active utility bill subscriptions.</p>
</section>
<?php
app_footer();
?>