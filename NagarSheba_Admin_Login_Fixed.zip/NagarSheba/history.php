<?php
require_once 'partials.php';
require_login();
$q=db()->prepare("SELECT p.*,b.service FROM payments p JOIN bills b ON b.id=p.bill_id WHERE p.user_id=? ORDER BY p.paid_at DESC");
$q->execute([$_SESSION['user_id']]);
$rows=$q->fetchAll();
app_header('Payment History', 'Payment History');
?><div class="page-heading">
<div>
<h1>Payment History</h1>
<p>Review your completed utility bill payments and receipts.</p>
</div>
</div>
<section class="panel">
<div class="table-wrap">
<table>
<thead>
<tr>
<th>Transaction ID</th>
<th>Utility</th>
<th>Amount</th>
<th>Method</th>
<th>Payment Date</th>
<th>Status</th>
<th>Receipt</th>
</tr>
</thead>
<tbody>
<?php
if(!$rows):
?><tr>
<td colspan="7" class="empty">No payment history yet. Pay an unpaid bill to see it here.</td>
</tr>
<?php
endif;
?><?php
foreach($rows as $r):
?><tr>
<td>
<?=
e($r['transaction_id'])
?></td>
<td>
<?=
e($r['service'])
?></td>
<td>
<?=
money($r['amount'])
?></td>
<td>
<?=
e($r['method'])
?></td>
<td>
<?=
date('d M Y', strtotime($r['paid_at']))
?></td>
<td>
<span class="status paid">Successful</span>
</td>
<td>
<a class="text-link" href="receipt.php?id=
<?=
$r['id']
?>">View Receipt</a>
</td>
</tr>
<?php
endforeach;
?></tbody>
</table>
</div>
</section>
<?php
app_footer();
?>