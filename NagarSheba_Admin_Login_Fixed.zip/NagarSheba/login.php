<?php
require_once 'config.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    $email=strtolower(trim($_POST['email']??''));
    $pass=$_POST['password']??'';
    $q=db()->prepare("SELECT id,password_hash,role,is_active FROM users WHERE email=?");
    $q->execute([$email]);
    $u=$q->fetch();
    if($u && $u['role']==='user' && (int)$u['is_active']===1 && password_verify($pass, $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id']=$u['id'];
        $_SESSION['role']=$u['role'];
        header('Location: '.($u['role']==='admin'?'admin-dashboard.php':'dashboard.php'));
        exit;
    }
    $error='User email or password is incorrect. Admins must use Admin Panel Login.';
}
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login | NagarSheba</title>
<link rel="stylesheet" href="assets/style.css?v=20261103-fixed">
</head>
<body class="auth-body">
<a class="auth-brand" href="index.php">NagarSheba <small>Smart Utility System</small>
</a>
<main class="auth-card login-card">
<h1>Welcome Back!</h1>
<p class="muted center">Login to continue to your account</p>
<?php
if($error):
?><div class="alert">
<?=
e($error)
?></div>
<?php
endif;
?><form method="post">
<?=
csrf_field()
?><label>Email Address<input type="email" name="email" placeholder="Enter your email" required value="
<?=
e($_POST['email']??'')
?>">
</label>
<label>Password<input type="password" name="password" placeholder="Enter your password" required>
</label>
<div class="form-between">
<label class="check">
<input type="checkbox" name="remember"> Remember Me</label>
<a href="#" onclick="alert('Please contact the project administrator to reset your demo password.');return false">Forgot Password?</a>
</div>
<button class="btn full">Login</button>
</form>
<p class="center muted">Don't have an account? <a href="register.php">Register here</a>
</p>
<p class="center muted"><a href="admin-login.php">Admin Panel Login</a></p>
</main>
</body>
</html>
