CREATE DATABASE IF NOT EXISTS nagarsheba CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nagarsheba;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(40) DEFAULT '',
 address VARCHAR(255) DEFAULT '',
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('user','admin') NOT NULL DEFAULT 'user',
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE bills (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 service ENUM('Electricity','Gas','Water','WiFi') NOT NULL,
 customer_id VARCHAR(60) NOT NULL,
 amount DECIMAL(10,2) NOT NULL DEFAULT 0,
 late_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
 billing_month CHAR(7) NOT NULL,
 due_date DATE NOT NULL,
 status ENUM('Unpaid','Paid') NOT NULL DEFAULT 'Unpaid',
 paid_at DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY unique_customer_service_month(user_id,service,billing_month),
 CONSTRAINT fk_bills_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 bill_id INT NOT NULL,
 transaction_id VARCHAR(80) NOT NULL UNIQUE,
 amount DECIMAL(10,2) NOT NULL,
 method VARCHAR(40) NOT NULL,
 note VARCHAR(255) DEFAULT '',
 status ENUM('Successful','Failed') NOT NULL DEFAULT 'Successful',
 paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_pay_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_pay_bill FOREIGN KEY(bill_id) REFERENCES bills(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE billing_plans (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 service ENUM('Electricity','Gas','Water','WiFi') NOT NULL,
 customer_id VARCHAR(60) NOT NULL,
 amount DECIMAL(10,2) NOT NULL DEFAULT 0,
 late_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
 active TINYINT(1) NOT NULL DEFAULT 1,
 UNIQUE KEY unique_plan_user_service(user_id,service),
 CONSTRAINT fk_plan_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
