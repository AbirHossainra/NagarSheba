<?php
require_once 'partials.php';
require_login();
$u=current_user();
$error='';
if($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    $name=trim($_POST['full_name']??'');
    $phone=trim($_POST['phone']??'');
    $address=trim($_POST['address']??'');
    if($name) {
        $q=db()->prepare("UPDATE users SET full_name=?,phone=?,address=? WHERE id=?");
        $q->execute([$name, $phone, $address, $_SESSION['user_id']]);
        flash('Profile updated successfully.');
        header('Location: profile.php');
        exit;
    }
    else $error='Name is required.';
}
app_header('Profile & Settings', 'Profile');
?><div class="page-heading">
<div>
<h1>Profile & Settings</h1>
<p>Update your NagarSheba account details.</p>
</div>
</div>
<section class="panel form-panel">
<?php
if($error):
?><div class="alert">
<?=
e($error)
?></div>
<?php
endif;
?><form method="post">
<?=
csrf_field()
?><label>Full Name<input name="full_name" required value="
<?=
e($u['full_name'])
?>">
</label>
<label>Email Address<input value="
<?=
e($u['email'])
?>" disabled>
</label>
<label>Phone Number<input name="phone" value="
<?=
e($u['phone'])
?>">
</label>
<label>Address<input name="address" value="
<?=
e($u['address'])
?>">
</label>
<button class="btn">Save Changes</button>
</form>
</section>
<?php
app_footer();
?>